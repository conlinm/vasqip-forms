import React, { Component } from 'react'

export default class CaseList extends Component {
  render() {
    return (
      <div>
        <p>You are on the Case List component.</p>
      </div>
    )
  }
}