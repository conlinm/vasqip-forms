import React, { Component } from 'react'

export default class EditDataEntry extends Component {
  render() {
    return (
      <div>
        <p>You are on the Edit Data Entry component.</p>
      </div>
    )
  }
}