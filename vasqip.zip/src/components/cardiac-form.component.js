import React, { Component } from 'react'

export default class CaseList extends Component {
  render() {
    return (
      <div>
        <p>You are on the Cardiac Form component.</p>
      </div>
    )
  }
}