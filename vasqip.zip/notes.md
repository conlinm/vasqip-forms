aws server: http://vasqipapp-env.ynu4h2p8pz.us-west-2.elasticbeanstalk.com/non-cardiacq

git command to create zip file, run within the /vasqip-forms folder:
git archive -v -o vasqip.zip --format=zip HEAD